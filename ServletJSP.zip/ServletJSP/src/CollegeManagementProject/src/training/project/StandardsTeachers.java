package CollegeManagementProject.src.training.project;



import java.util.List;

public interface StandardsTeachers {
	public boolean insertTeacher(Teacher t);
	public Teacher getTeacher(int id);
	public List<Teacher> getAllTeachers();

	
	
	

}
