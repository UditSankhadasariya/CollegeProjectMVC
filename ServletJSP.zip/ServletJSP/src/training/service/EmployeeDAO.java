package training.service;

import java.util.List;

import jdbc.beans.*;

public class EmployeeDAO {
	public List<Employee> getAllEmployees(){
		return new jdbc.dao.EmployeeDAO().getAllEmployees();
	}
}
