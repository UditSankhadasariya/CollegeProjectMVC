package training.servlet.service;

import training.servlet.beans.LoginBean;

public class UserBL {
	public boolean validateUser(LoginBean lb) {
		
		return  lb.getUserName().equals("Udit")&&lb.getPasword().equals("sapient");
	}
}
