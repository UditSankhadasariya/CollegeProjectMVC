package training.servlet.basic;

import java.util.Arrays;
import java.util.List;

public class Logic {
	public static List<Employee> getEmployees(){
		List<Employee> employees = Arrays.asList(
				new Employee("Hello",1),
				new Employee("Hi",2)
				);
		return employees;
	}
	

}
