package training.servlet.basic;

import java.util.List;

public interface StandardsTeachers {
	public boolean insertTeacher(Teacher t);
	public Teacher getTeacher(int id);
	public List<Teacher> getAllTeachers();

	
	
	

}
