package training.servlet.beans;

public class LoginBean {
	private String userName;
	private String pasword;

	public LoginBean() {
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPasword() {
		return pasword;
	}

	public void setPasword(String pasword) {
		this.pasword = pasword;
	}

	@Override
	public String toString() {
		return "LoginBean [userName=" + userName + ", pasword=" + pasword + "]";
	}

	public LoginBean(String userName, String pasword) {
		super();
		this.userName = userName;
		this.pasword = pasword;
	}

}
